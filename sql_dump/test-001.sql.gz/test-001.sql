-- Adminer 4.3.1 PostgreSQL dump

\connect "test-001";

DROP TABLE IF EXISTS "recipes";
CREATE SEQUENCE recipes_id_seq INCREMENT  MINVALUE  MAXVALUE  START 11 CACHE ;

CREATE TABLE "public"."recipes" (
    "id" integer DEFAULT nextval('recipes_id_seq') NOT NULL,
    "title" character varying(64) NOT NULL,
    "description" text,
    CONSTRAINT "recipes_id" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "recipes" ("id", "title", "description") VALUES
(1,	'Водка',	'вода - 60%
спирт этиловый - 40%
смешать'),
(3,	'Кровавая Мери',	'томатный сок
водка'),
(4,	'ффыыыыффффыыы',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!'),
(5,	'ффыыыыффффыыы',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!'),
(6,	'ффыыыыффффыыы22',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!33'),
(7,	'ффыыыыффффыыы2255',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!344'),
(8,	'ффыыыыффффыыыQQQ',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!AAA'),
(9,	'ффыыыыффффыыыQQQ2',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!AAA2'),
(10,	'ффыыыыффффыыыQQQ3',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!AAA3'),
(11,	'ффыыыыффффыыыQQQ3',	'ееееннннн ггггггнеееееее оогггггоооооггггоо!!!!AAA3');

DROP TABLE IF EXISTS "users";
CREATE SEQUENCE users_id_seq INCREMENT  MINVALUE  MAXVALUE  START 5 CACHE ;

CREATE TABLE "public"."users" (
    "id" integer DEFAULT nextval('users_id_seq') NOT NULL,
    "name" character varying(32) NOT NULL,
    "passw" character varying(64) NOT NULL,
    "userkey" character varying(16),
    "protected" integer DEFAULT 0 NOT NULL,
    "sid" character varying(64),
    CONSTRAINT "users_id" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "users" ("id", "name", "passw", "userkey", "protected", "sid") VALUES
(2,	'user01',	'b59c67bf196a4758191e42f76670ceba',	'12345',	0,	NULL),
(3,	'petja',	'b59c67bf196a4758191e42f76670ceba',	'12345',	0,	NULL),
(4,	'Константин',	'b59c67bf196a4758191e42f76670ceba',	'12345',	0,	NULL),
(5,	'vasjya',	'b59c67bf196a4758191e42f76670ceba',	'12345',	0,	''),
(1,	'admin',	'21232f297a57a5a743894a0e4a801fc3',	'09876',	1,	'');

DROP TABLE IF EXISTS "sessions";
CREATE SEQUENCE sessions_id_seq INCREMENT  MINVALUE  MAXVALUE  START 21 CACHE ;

CREATE TABLE "public"."sessions" (
    "id" integer DEFAULT nextval('sessions_id_seq') NOT NULL,
    "sid" character varying(64) NOT NULL,
    "user_id" integer DEFAULT 0 NOT NULL,
    "begin" timestamp,
    "lastvisit" timestamp,
    CONSTRAINT "sessions_id" PRIMARY KEY ("id"),
    CONSTRAINT "sessions_sid" UNIQUE ("sid")
) WITH (oids = false);

INSERT INTO "sessions" ("id", "sid", "user_id", "begin", "lastvisit") VALUES
(21,	'f3937968ed134cf524d291cede4f0317',	0,	'2018-04-28 17:18:25.498164',	'2018-04-28 18:19:05.873381');

DROP TABLE IF EXISTS "photo";
CREATE SEQUENCE photo_id_seq INCREMENT  MINVALUE  MAXVALUE  START 13 CACHE ;

CREATE TABLE "public"."photo" (
    "id" integer DEFAULT nextval('photo_id_seq') NOT NULL,
    "recipe_id" integer NOT NULL,
    "filename" character varying(64) NOT NULL,
    "description" character varying(16) DEFAULT NULL,
    CONSTRAINT "photo_id" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "photo" ("id", "recipe_id", "filename", "description") VALUES
(5,	1,	'IpEvpQFLLT4jWy8b.jpg',	NULL),
(6,	1,	'zKvPwgmmgjAkKuyi.jpg',	NULL),
(7,	1,	'bsseDXoarfEmKBWp.jpg',	NULL),
(8,	1,	'hmdwhgMV9OcXsglc.jpg',	NULL),
(9,	1,	'xuNsVU5CWTHCLune.jpg',	NULL),
(11,	1,	'JzNdR5ocVdgOnql4.jpg',	NULL),
(13,	1,	'KX2iD0cBNmiNMr1q.jpg',	NULL);

-- 2018-04-28 19:21:44.407958+03
